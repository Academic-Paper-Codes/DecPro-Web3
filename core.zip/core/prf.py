import hmac, hashlib

def prf(key: bytes, msg: bytes, out_len: int = 32, dst: bytes = b"PRF") -> bytes:
    mac = hmac.new(key, dst + msg, hashlib.sha256).digest()
    if out_len <= len(mac):
        return mac[:out_len]
    # 简单扩展（多次迭代）
    out = b""
    counter = 0
    while len(out) < out_len:
        out += hmac.new(key, mac + counter.to_bytes(4, "big"), hashlib.sha256).digest()
        counter += 1
    return out[:out_len]

def prf_scalar(key: bytes, msg: bytes, p: int, dst: bytes = b"PRF-S") -> int:
    digest = prf(key, msg, out_len=64, dst=dst)
    return (int.from_bytes(digest, "big") % (p - 1)) + 1