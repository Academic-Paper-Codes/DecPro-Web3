import hashlib
from hmac import digest
from typing import Optional
from .bilinear_group import BilinearGroup, G1Point, GTElement, FIELD_BYTES

def _blake2b(data: bytes, outlen: int = 32, key: Optional[bytes] = None, person: Optional[bytes] = None) -> bytes:
    '''blake2b implementation'''
    h = hashlib.blake2b(digest_size=outlen, key=key or b'', person=person or b'')
    h.update(data)
    return h.digest()

def hash_to_scalar(data: bytes, p: int, dst: bytes = b'H1') -> int:
    digest = _blake2b(dst + data, outlen=64)
    return (int.from_bytes(digest, 'big') % (p - 1)) + 1

# 这种实现非标准
def hash_to_g1(data: bytes, bg: BilinearGroup, dst: bytes = b'H1G1') -> G1Point:
    x = hash_to_scalar(data, bg.p, dst=dst)
    return bg.g1_mul(bg.G1, x)

# TODO: 这种方法使用了序列化，如果序列化函数被修改，这里可能也要修改
def _flatten_coeffs(element) -> bytes:
    if hasattr(element, "coeffs"):
        parts = []
        for c in element.coeffs:
            parts.append(_flatten_coeffs(c))
        return b"".join(parts)
    if hasattr(element, "n"):
        return int(element.n).to_bytes(FIELD_BYTES, "big", signed=False)
    if isinstance(element, int):
        return element.to_bytes(FIELD_BYTES, "big", signed=False)
    raise TypeError(f"Unsupported GT element component type: {type(element)}")

def kdf_from_gt(Z: GTElement, length: int, dst: bytes = b'H2') -> bytes:
    blob = dst + b"|" + _flatten_coeffs(Z)
    okm = b""
    counter = 0
    while len(okm) < length:
        okm += _blake2b(blob + counter.to_bytes(4, "big"), outlen=32)
        counter += 1
    return okm[:length]