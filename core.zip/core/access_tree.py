from __future__ import annotations

from secrets import randbelow
from typing import Iterable, List, Optional, Tuple

from .abe_types import AttributeRef, MAABEError
from utils.lagrange import lagrange_coefficients

def rand_scalar(b):
    # modified randbelow, return a integer in [1, b)
    return randbelow(b - 1) + 1


def _evaluate_polynomial(coeffs: List[int], x: int, p: int) -> int:
    """Evaluate polynomial defined by coeffs at x modulo p using Horner's rule."""
    acc = 0
    x_mod = x % p
    for coef in reversed(coeffs):
        acc = (acc * x_mod + (coef % p)) % p
    return acc

class AccessTreeNode:
    def __init__(self, threshold: int, children: Optional[List["AccessTreeNode"]] = None, attr: AttributeRef = None):
        self.threshold = threshold
        self.children = children or []
        self.attr = attr
        self.secret_main = 0  # q_main(0)
        self.secret_aux = 0  # q_aux(0)


    def is_leaf(self) -> bool:
        return self.attr is not None

    def assign_secrets(self, secret_main: int, p: int, is_aux: bool = False):
        if is_aux:
            self.secret_aux = secret_main
        else:
            self.secret_main = secret_main
        if not self.is_leaf():
            n = len(self.children)
            if self.threshold > n:
                raise MAABEError("Threshold exceeds number of children")
            # 多项式的常数项为 secret_main，其余系数随机
            poly = [secret_main] + [rand_scalar(p) for _ in range(self.threshold - 1)]
            for idx, child in enumerate(self.children, 1):
                share = _evaluate_polynomial(poly, idx, p)
                child.assign_secrets(share, p, is_aux)

    def reconstruct(self, satisfied_children: List['AccessTreeNode'], p: int, is_aux: bool = False) -> int:
        if not satisfied_children:
            raise MAABEError("No satisfied children")
        if len(satisfied_children) < self.threshold:
            raise MAABEError("Not enough children to satisfy threshold")
        shares = []
        for idx, node in enumerate(satisfied_children, 1):
            share_value = node.secret_aux if is_aux else node.secret_main
            shares.append((idx, share_value % p))
        indices = [idx for idx, _ in shares]
        coeffs = lagrange_coefficients(indices, p)
        secret = 0
        for (_, y_j), delta in zip(shares, coeffs):
            secret = (secret + y_j * delta) % p
        return secret

    # ---- helpers for policy handling ----
    def iter_leaves(self) -> Iterable["AccessTreeNode"]:
        if self.is_leaf():
            yield self
        else:
            for child in self.children:
                yield from child.iter_leaves()

    def sample_leaf_shares(self, secret: int, p: int) -> List[Tuple[AttributeRef, int]]:
        """
        Sample per-leaf shares without mutating the tree, used during encryption.
        """
        shares: List[Tuple[AttributeRef, int]] = []
        seen: set[AttributeRef] = set()
        self._populate_leaf_shares(secret % p, p, shares, seen)
        return shares

    def _populate_leaf_shares(
        self,
        secret: int,
        p: int,
        shares: List[Tuple[AttributeRef, int]],
        seen: set[AttributeRef],
    ) -> None:
        if self.is_leaf():
            if self.attr is None:
                raise MAABEError("Leaf node missing attribute reference")
            if self.attr in seen:
                raise MAABEError(f"Duplicate attribute in policy tree: {self.attr}")
            seen.add(self.attr)
            shares.append((self.attr, secret % p))
            return
        if self.threshold > len(self.children):
            raise MAABEError("Threshold exceeds number of children")
        poly = [secret % p] + [rand_scalar(p) for _ in range(self.threshold - 1)]
        for idx, child in enumerate(self.children, 1):
            share = _evaluate_polynomial(poly, idx, p)
            child._populate_leaf_shares(share, p, shares, seen)

    def clone(self, include_secrets: bool = False) -> "AccessTreeNode":
        cloned_children = [child.clone(include_secrets) for child in self.children] if self.children else []
        clone = AccessTreeNode(self.threshold, cloned_children, self.attr)
        if include_secrets:
            clone.secret_main = self.secret_main
            clone.secret_aux = self.secret_aux
        return clone

    def to_dict(self) -> dict:
        return {
            "threshold": self.threshold,
            "attr": {"authority_id": self.attr.authority_id, "attribute": self.attr.attribute} if self.attr else None,
            "children": [child.to_dict() for child in self.children],
        }

    @staticmethod
    def from_dict(data: dict) -> "AccessTreeNode":
        attr_data = data.get("attr")
        attr = AttributeRef(attr_data["authority_id"], attr_data["attribute"]) if attr_data else None
        children = [AccessTreeNode.from_dict(child) for child in data.get("children", [])]
        return AccessTreeNode(data["threshold"], children, attr)