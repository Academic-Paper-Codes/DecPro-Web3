from __future__ import annotations

from secrets import randbelow
from typing import Iterable, List, Sequence, Tuple

from .abe_types import AttributeRef
from utils.lagrange import matrix_rank_mod


def _rand_scalar(p: int) -> int:
    return randbelow(p - 1) + 1


def _solve_linear_system_mod(A: List[List[int]], b: List[int], p: int) -> List[int]:
    if not A:
        raise ValueError("Empty matrix provided for solving")
    rows = len(A)
    cols = len(A[0])
    aug = [A[r][:] + [b[r] % p] for r in range(rows)]
    rank = 0
    pivot_cols: List[int] = []

    for col in range(cols):
        pivot_row = None
        for r in range(rank, rows):
            if aug[r][col] % p != 0:
                pivot_row = r
                break
        if pivot_row is None:
            continue
        aug[rank], aug[pivot_row] = aug[pivot_row], aug[rank]
        inv = pow(aug[rank][col], -1, p)
        for c in range(col, cols + 1):
            aug[rank][c] = (aug[rank][c] * inv) % p
        for r in range(rows):
            if r == rank:
                continue
            factor = aug[r][col] % p
            if factor == 0:
                continue
            for c in range(col, cols + 1):
                aug[r][c] = (aug[r][c] - factor * aug[rank][c]) % p
        pivot_cols.append(col)
        rank += 1
        if rank == rows:
            break

    for r in range(rank, rows):
        if aug[r][-1] % p != 0:
            raise ValueError("Linear system has no solution over the given field")

    solution = [0] * cols
    for r, col in enumerate(pivot_cols):
        solution[col] = aug[r][-1] % p
    return solution


class LSSSMatrix:
    """
    线性秘密共享 (LSSS) 矩阵表示：
    rows: List[Sequence[int]]
    attrs: List[AttributeRef] 对应每一行关联的属性。
    """

    def __init__(
        self,
        rows: Sequence[Sequence[int]] | Sequence[Tuple[Sequence[int], AttributeRef]],
        row_attrs: Sequence[AttributeRef] | None = None,
    ) -> None:
        rows_list = list(rows)
        if row_attrs is None:
            if rows_list and isinstance(rows_list[0], tuple):
                vectors, attrs = zip(*rows_list)  # type: ignore
            else:
                raise ValueError("Either provide row_attrs or rows as (vector, attr) tuples")
        else:
            vectors = rows_list
            attrs = row_attrs
        self.matrix: List[List[int]] = [list(map(int, vec)) for vec in vectors]
        self.row_attrs: List[AttributeRef] = list(attrs)
        if not self.matrix:
            raise ValueError("LSSS matrix cannot be empty")
        width = len(self.matrix[0])
        for row in self.matrix:
            if len(row) != width:
                raise ValueError("All rows in LSSS matrix must have the same length")
        if len(self.matrix) != len(self.row_attrs):
            raise ValueError("Row count and attribute mapping size mismatch")
        self.width = width

    def to_dict(self) -> dict:
        return {
            "matrix": self.matrix,
            "attrs": [{"authority_id": a.authority_id, "attribute": a.attribute} for a in self.row_attrs],
        }

    @staticmethod
    def from_dict(data: dict) -> "LSSSMatrix":
        attrs = [AttributeRef(entry["authority_id"], entry["attribute"]) for entry in data["attrs"]]
        return LSSSMatrix(data["matrix"], attrs)

    def generate_shares(self, secret: int, p: int) -> List[Tuple[AttributeRef, int]]:
        v = [secret] + [_rand_scalar(p) for _ in range(self.width - 1)]
        shares: List[Tuple[AttributeRef, int]] = []
        for row, attr in zip(self.matrix, self.row_attrs):
            accum = 0
            for coeff, variate in zip(row, v):
                accum = (accum + (coeff % p) * variate) % p
            shares.append((attr, accum))
        return shares

    def satisfy(self, attrs: Sequence[AttributeRef], p: int) -> List[Tuple[AttributeRef, int]]:
        attr_set = set(attrs)
        available: List[Tuple[int, List[int], AttributeRef]] = []
        for idx, (row, attr) in enumerate(zip(self.matrix, self.row_attrs)):
            if attr in attr_set:
                available.append((idx + 1, row, attr))
        if not available:
            raise ValueError("Provided attributes do not match any policy rows")

        selected_rows: List[List[int]] = []
        selected_attrs: List[AttributeRef] = []
        current_rank = 0
        for index, row, attr in available:
            candidate = selected_rows + [row]
            new_rank = matrix_rank_mod(candidate, p)
            if new_rank > current_rank:
                selected_rows.append(row)
                selected_attrs.append(attr)
                current_rank = new_rank
                if len(selected_rows) == self.width:
                    break
        if current_rank < self.width:
            raise ValueError("Attributes do not satisfy the access policy")

        transpose = [[row[col] % p for row in selected_rows] for col in range(self.width)]
        target = [1] + [0] * (self.width - 1)
        omega = _solve_linear_system_mod(transpose, target, p)
        return list(zip(selected_attrs, omega))