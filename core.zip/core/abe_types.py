from __future__ import annotations

from dataclasses import dataclass


class MAABEError(Exception):
    """Base exception for DecPro MA-ABE module."""


@dataclass(frozen=True)
class AttributeRef:
    authority_id: str
    attribute: str

    def __str__(self) -> str:
        return f"{self.authority_id}:{self.attribute}"

