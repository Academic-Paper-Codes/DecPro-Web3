from typing import Tuple

class HomomorphicEncryptor:
    def keygen(self): raise NotImplementedError
    def encrypt(self, m: int): raise NotImplementedError
    def add(self, c1, c2): raise NotImplementedError
    def mul_const(self, c, k: int): raise NotImplementedError
    def decrypt(self, c): raise NotImplementedError

class InsecureAdditiveHE(HomomorphicEncryptor):
    # not secure
    def __init__(self, modulus: int = 2**61-1) -> None:
        self.n = modulus

    def keygen(self): return None

    def encrypt(self, m: int) -> int:
        return m % self.n

    def add(self, c1: int, c2: int) -> int:
        return (c1 + c2) % self.n

    def mul_const(self, c: int, k: int) -> int:
        return (c * k) % self.n

    def decrypt(self, c: int) -> int:
        return c

try:
    # if have phe lib, use it. otherwise using insecure one.
    import phe  
    class PaillierEncryptor(HomomorphicEncryptor):
        def keygen(self):
            self.pub, self.priv = phe.generate_paillier_keypair()
            return self.pub, self.priv

        def encrypt(self, m: int):
            return self.pub.encrypt(m)

        def add(self, c1, c2):
            return c1 + c2

        def mul_const(self, c, k: int):
            return c * k

        def decrypt(self, c):
            return self.priv.decrypt(c)
except Exception:
    PaillierEncryptor = None 

if __name__ == "__main__":
    if PaillierEncryptor is None:
        raise RuntimeError("未安装 phe 库，无法演示 Paillier 同态加密器")
    he = PaillierEncryptor()
    he.keygen()
    m1, m2 = 10, 20
    c1 = he.encrypt(m1)
    c2 = he.encrypt(m2)
    c1_plus_c2 = he.add(c1, c2)
    print(c1_plus_c2)
    print(he.decrypt(c1_plus_c2))
