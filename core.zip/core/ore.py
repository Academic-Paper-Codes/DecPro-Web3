from __future__ import annotations

from typing import Any, Dict, Optional, Tuple, Union

try:
    from pyope.ope import OPE, ValueRange
except ImportError as _exc:  # pragma: no cover - optional dependency guard
    OPE = None  # type: ignore
    ValueRange = None  # type: ignore
    _IMPORT_ERROR = _exc
else:  # pragma: no cover - simple assignment
    _IMPORT_ERROR = None


Ciphertext = Union[int, bytes, bytearray]
RangeTuple = Tuple[int, int]


class ORE:
    """
    Order-preserving encryption wrapper based on the ``pyope`` package
    (Boldyreva OPE scheme). Interface保持与原占位实现一致：

    - ``keygen()`` 生成并返回密钥
    - ``encrypt_int(x)`` 返回可以比较顺序的密文
    - ``compare(ct1, ct2)`` 比较两个密文的大小关系
    """

    def __init__(
        self,
        key: Optional[bytes] = None,
        *,
        in_range: Optional[RangeTuple] = None,
        out_range: Optional[RangeTuple] = None,
    ) -> None:
        if OPE is None:
            raise ImportError(
                "pyope 库未安装，无法使用 ORE。请执行 `pip install pyope`。"
            ) from _IMPORT_ERROR

        self._cipher_kwargs: Dict[str, Any] = {}
        if in_range is not None:
            self._cipher_kwargs["in_range"] = ValueRange(*in_range)  # type: ignore[arg-type]
        if out_range is not None:
            self._cipher_kwargs["out_range"] = ValueRange(*out_range)  # type: ignore[arg-type]

        self.key: Optional[bytes] = None
        self._cipher: Optional[OPE] = None  # type: ignore[assignment]

        if key is None:
            self.keygen()
        else:
            self._init_cipher(key)

    def keygen(self) -> bytes:
        key = OPE.generate_key()  # type: ignore[union-attr]
        self._init_cipher(key)
        return key

    def encrypt_int(self, x: int) -> int:
        self._ensure_cipher()
        return self._cipher.encrypt(x)  # type: ignore[union-attr]

    def compare(self, ct1: Ciphertext, ct2: Ciphertext) -> int:
        c1 = self._normalize_ciphertext(ct1)
        c2 = self._normalize_ciphertext(ct2)
        return (c1 > c2) - (c1 < c2)

    # ---- internal helpers -------------------------------------------------
    def _init_cipher(self, key: bytes) -> None:
        self.key = key
        self._cipher = OPE(key, **self._cipher_kwargs)  # type: ignore[operator]

    def _ensure_cipher(self) -> None:
        if self._cipher is None or self.key is None:
            raise RuntimeError("ORE 密钥未初始化，请先调用 keygen() 或提供密钥")

    @staticmethod
    def _normalize_ciphertext(ct: Ciphertext) -> int:
        if isinstance(ct, int):
            return ct
        if isinstance(ct, (bytes, bytearray)):
            return int.from_bytes(ct, "big", signed=False)
        raise TypeError(f"不支持的密文类型：{type(ct)!r}")


if __name__ == "__main__":  # pragma: no cover
    ore = ORE()
    c1 = ore.encrypt_int(1)
    c2 = ore.encrypt_int(2)
    print("ciphertext1 =", c1)
    print("ciphertext2 =", c2)
    print("compare =", ore.compare(c1, c2))