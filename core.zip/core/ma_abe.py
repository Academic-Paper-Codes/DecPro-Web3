from dataclasses import dataclass, field
from typing import Any, Dict, List, Mapping, Sequence, Tuple, Union

from .bilinear_group import BilinearGroup, G1Point, G2Point, GTElement
from .hash_functions import kdf_from_gt
from .symmetric_enc import KEY_SIZE, aead_encrypt, aead_decrypt
from .abe_types import AttributeRef, MAABEError

@dataclass
class GlobalParameters:
    group: BilinearGroup
    pairing_base: GTElement  # e(G1, G2)

@dataclass
class AuthoritySecretKey:
    authority_id: str
    attribute_secrets: Dict[str, int] = field(default_factory=dict)
    attribute_inverses: Dict[str, int] = field(default_factory=dict)
    attribute_g2_components: Dict[str, G2Point] = field(default_factory=dict)

@dataclass
class AuthorityPublicKey:
    authority_id: str
    attribute_keys: Dict[str, G1Point] = field(default_factory=dict)

@dataclass
class AuthorityKeyPair:
    secret: AuthoritySecretKey
    public: AuthorityPublicKey

@dataclass
class MAABEUserSecretKey:
    components: Dict[AttributeRef, G2Point] = field(default_factory=dict)

    def merge(self, other: "MAABEUserSecretKey") -> "MAABEUserSecretKey":
        self.components.update(other.components)
        return self

    def has_attributes(self, attrs: List[AttributeRef]) -> bool:
        return all(attr in self.components for attr in attrs)

@dataclass
class CiphertextHeader:
    c_main: G1Point
    components: Dict[AttributeRef, G1Point]

@dataclass
class MAABECiphertext:
    policy: List[AttributeRef]
    header: CiphertextHeader
    payload: bytes
    aad: bytes = b""
    policy_info: Dict[str, Any] | None = None


from .access_matrix import LSSSMatrix
from .access_tree import AccessTreeNode
from utils.lagrange import lagrange_coefficients


PolicyInput = Union[Sequence[AttributeRef], LSSSMatrix, AccessTreeNode]


class MultiAuthorityABE:
    def __init__(self, group: BilinearGroup | None = None) -> None:
        self.group = group or BilinearGroup()
        self.params = GlobalParameters(
            group=self.group,
            pairing_base=self.group.pair(self.group.G1, self.group.G2)
        )

    def setup_authority(self, authority_id: str, attributes: List[str]) -> AuthorityKeyPair:
        attribute_secrets: Dict[str, int] = {}
        attribute_inverses: Dict[str, int] = {}
        attribute_g2_components: Dict[str, G2Point] = {}
        attribute_publics: Dict[str, G1Point] = {}
        for attr in set(attributes):
            t_attr = self.group.rand_scalar()
            attribute_secrets[attr] = t_attr
            attribute_publics[attr] = self.group.g1_mul(self.group.G1, t_attr)
            inv_t = pow(t_attr, -1, self.group.p)
            attribute_inverses[attr] = inv_t
        secret = AuthoritySecretKey(
            authority_id,
            attribute_secrets,
            attribute_inverses,
            attribute_g2_components,
        )
        public = AuthorityPublicKey(authority_id, attribute_publics)
        return AuthorityKeyPair(secret, public)

    def issue_user_keys(
        self, auth_secret: AuthoritySecretKey, attributes: List[str]
    ) -> MAABEUserSecretKey:
        user_key = MAABEUserSecretKey()
        for attr in attributes:
            t_attr = auth_secret.attribute_secrets.get(attr)
            if t_attr is None:
                raise MAABEError(f"Attribute '{attr}' not in authority '{auth_secret.authority_id}'")
            key_comp = auth_secret.attribute_g2_components.get(attr)
            if key_comp is None:
                inv_t = auth_secret.attribute_inverses.get(attr)
                if inv_t is None:
                    inv_t = pow(t_attr, -1, self.group.p)
                    auth_secret.attribute_inverses[attr] = inv_t
                key_comp = self.group.g2_mul(self.group.G2, inv_t)
                auth_secret.attribute_g2_components[attr] = key_comp
            attr_ref = AttributeRef(auth_secret.authority_id, attr)
            user_key.components[attr_ref] = key_comp
        return user_key

    def encrypt(
        self,
        plaintext: bytes,
        policy: PolicyInput,
        public_keys: Mapping[str, AuthorityPublicKey],
        aad: bytes = b"",
    ) -> MAABECiphertext:
        if isinstance(policy, LSSSMatrix):
            s = self.group.rand_scalar()
            shares = policy.generate_shares(s, self.group.p)
            policy_attrs = [attr for attr, _ in shares]
            if len(set(policy_attrs)) != len(policy_attrs):
                raise MAABEError("Duplicate attributes in LSSS policy rows")
            policy_info = {"type": "matrix", "structure": policy.to_dict()}
        else:
            if isinstance(policy, AccessTreeNode):
                tree = policy.clone(include_secrets=False)
            else:
                policy_list = list(policy)
                if not policy_list:
                    raise MAABEError("Policy can not be empty")
                if len(set(policy_list)) != len(policy_list):
                    raise MAABEError("Duplicate attributes in policy list")
                tree = self._build_all_of_tree(policy_list)
            s = self.group.rand_scalar()
            shares = tree.sample_leaf_shares(s, self.group.p)
            policy_attrs = [attr for attr, _ in shares]
            policy_info = {"type": "tree", "structure": tree.to_dict()}

        if not shares:
            raise MAABEError("Failed to derive attribute shares for policy")

        pub_lookup: Dict[AttributeRef, G1Point] = {}
        for attr_ref in policy_attrs:
            auth_pub = public_keys.get(attr_ref.authority_id)
            if auth_pub is None:
                raise MAABEError(f"No public key for authority: '{attr_ref.authority_id}'")
            pk_attr = auth_pub.attribute_keys.get(attr_ref.attribute)
            if pk_attr is None:
                raise MAABEError(f"No public key for attribute '{attr_ref}'")
            pub_lookup[attr_ref] = pk_attr

        header_comps: Dict[AttributeRef, G1Point] = {}
        for attr_ref, share in shares:
            pk_attr = pub_lookup[attr_ref]
            header_comps[attr_ref] = self.group.g1_mul(pk_attr, share % self.group.p)

        c_main = self.group.g1_mul(self.group.G1, s)
        session_gt = self.group.gt_pow(self.params.pairing_base, s)
        sym_key = kdf_from_gt(session_gt, KEY_SIZE)
        payload = aead_encrypt(sym_key, plaintext, aad=aad)
        header = CiphertextHeader(c_main, header_comps)

        return MAABECiphertext(policy_attrs, header, payload, aad, policy_info)

    def decrypt(self, ciphertext: MAABECiphertext, user_key: MAABEUserSecretKey) -> bytes:
        policy_info = ciphertext.policy_info or {}
        policy_type = policy_info.get("type")

        if policy_type == "tree":
            tree_dict = policy_info.get("structure")
            if not tree_dict:
                raise MAABEError("Ciphertext missing policy structure")
            tree = AccessTreeNode.from_dict(tree_dict)
            gt_acc = self._decrypt_tree(tree, ciphertext, user_key)
        elif policy_type == "matrix":
            matrix_dict = policy_info.get("structure")
            if not matrix_dict:
                raise MAABEError("Ciphertext missing LSSS structure")
            matrix = LSSSMatrix.from_dict(matrix_dict)
            gt_acc = self._decrypt_matrix(matrix, ciphertext, user_key)
        else:
            gt_acc = self._decrypt_naive(ciphertext, user_key)

        if gt_acc is None:
            raise MAABEError("User attributes do not satisfy the access policy")

        sym_key = kdf_from_gt(gt_acc, KEY_SIZE)
        try:
            return aead_decrypt(sym_key, ciphertext.payload, ciphertext.aad)
        except Exception as exc:
            raise MAABEError("Decryption failed (likely invalid key)") from exc

    # ---- helpers ----
    def _build_all_of_tree(self, attrs: Sequence[AttributeRef]) -> AccessTreeNode:
        if not attrs:
            raise MAABEError("Policy can not be empty")
        if len(set(attrs)) != len(attrs):
            raise MAABEError("Duplicate attributes in policy definition")
        leaves = [AccessTreeNode(1, attr=attr) for attr in attrs]
        return AccessTreeNode(len(leaves), leaves)

    def _decrypt_tree(
        self,
        node: AccessTreeNode,
        ciphertext: MAABECiphertext,
        user_key: MAABEUserSecretKey,
    ):
        if node.is_leaf():
            attr = node.attr
            if attr is None:
                return None
            comp = ciphertext.header.components.get(attr)
            if comp is None:
                raise MAABEError(f"Missing ciphertext components for {attr}")
            key_comp = user_key.components.get(attr)
            if key_comp is None:
                return None
            return self.group.pair(comp, key_comp)

        child_results: List[Tuple[int, Any]] = []
        for idx, child in enumerate(node.children, 1):
            result = self._decrypt_tree(child, ciphertext, user_key)
            if result is not None:
                child_results.append((idx, result))
        if len(child_results) < node.threshold:
            return None

        indices = [idx for idx, _ in child_results]
        coeffs = lagrange_coefficients(indices, self.group.p)
        acc = None
        for (_, value), coeff in zip(child_results, coeffs):
            if coeff == 0:
                continue
            contrib = self.group.gt_pow(value, coeff)
            acc = contrib if acc is None else acc * contrib
        return acc

    def _decrypt_matrix(
        self,
        matrix: LSSSMatrix,
        ciphertext: MAABECiphertext,
        user_key: MAABEUserSecretKey,
    ):
        available_attrs = [attr for attr in matrix.row_attrs if attr in user_key.components]
        if not available_attrs:
            return None
        try:
            coeffs = matrix.satisfy(available_attrs, self.group.p)
        except ValueError as exc:
            raise MAABEError("Attributes do not satisfy LSSS policy") from exc
        acc = None
        for attr, coeff in coeffs:
            if coeff == 0:
                continue
            comp = ciphertext.header.components.get(attr)
            if comp is None:
                raise MAABEError(f"Missing ciphertext components for {attr}")
            key_comp = user_key.components.get(attr)
            if key_comp is None:
                raise MAABEError(f"Missing user key component for {attr}")
            pairing_val = self.group.pair(comp, key_comp)
            contrib = self.group.gt_pow(pairing_val, coeff)
            acc = contrib if acc is None else acc * contrib
        return acc

    def _decrypt_naive(self, ciphertext: MAABECiphertext, user_key: MAABEUserSecretKey):
        if not user_key.has_attributes(ciphertext.policy):
            return None
        acc = None
        for attr_ref in ciphertext.policy:
            c_attr = ciphertext.header.components.get(attr_ref)
            if c_attr is None:
                raise MAABEError(f"Missing ciphertext components for {attr_ref}")
            k_attr = user_key.components[attr_ref]
            pairing_val = self.group.pair(c_attr, k_attr)
            acc = pairing_val if acc is None else acc * pairing_val
        return acc


