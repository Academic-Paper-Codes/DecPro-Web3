import os
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

NONCE_SIZE = 12
KEY_SIZE = 32  # 256-bit

def aead_keygen() -> bytes:
    return os.urandom(KEY_SIZE)

def aead_encrypt(key: bytes, plaintext: bytes, aad: bytes = b"") -> bytes:
    aes = AESGCM(key)
    nonce = os.urandom(NONCE_SIZE)
    ct = aes.encrypt(nonce, plaintext, aad)
    return nonce + ct  # ct = ciphertext||tag

def aead_decrypt(key: bytes, blob: bytes, aad: bytes = b"") -> bytes:
    nonce, ct = blob[:NONCE_SIZE], blob[NONCE_SIZE:]
    aes = AESGCM(key)
    return aes.decrypt(nonce, ct, aad)