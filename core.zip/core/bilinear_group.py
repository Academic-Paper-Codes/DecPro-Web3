from __future__ import annotations
from dataclasses import dataclass
from typing import Tuple
import secrets

from py_ecc.bn128 import bn128_curve as curve
from py_ecc.bn128 import bn128_pairing as pairing

G1Point = Tuple[int, int]
G2Point = Tuple[Tuple[int, int], Tuple[int, int]]
GTElement = pairing.FQ12

FIELD_BYTES = 32

@dataclass(frozen=True)
class BilinearGroupParams:
    p: int
    G1: G1Point
    G2: G2Point

class BilinearGroup:
    def __init__(self) -> None:
        self.p = curve.curve_order
        self.G1 = curve.G1
        self.G2 = curve.G2
        self.params = BilinearGroupParams(self.p, self.G1, self.G2)

    # ---- sample random scalar ---- 
    def rand_scalar(self) -> int:
        '''sample [1, p - 1)'''
        return 1 + secrets.randbelow(self.p - 1) 

    # ---- G1 ops ----
    def g1_mul(self, P: G1Point, k: int) -> G1Point:
        return curve.multiply(P, k % self.p)

    def g1_add(self, P: G1Point, Q: G1Point) -> G1Point:
        return curve.add(P, Q)

    # ---- G2 ops ----
    def g2_mul(self, Q: G2Point, k: int) -> G2Point:
        return curve.multiply(Q, k % self.p)
    
    def g2_add(self, Q1: G2Point, Q2: G2Point) -> G2Point:
        return curve.add(Q1, Q2)

    # ---- pairing ---- 
    def pair(self, P: G1Point, Q: G2Point) -> GTElement:
        '''Q in G2, P in G1'''
        return pairing.pairing(Q, P)

    def gt_pow(self, Z: GTElement, k: int) -> GTElement:
        return  Z ** (k % self.p) 


    # ---- Minimal serialization (演示用，建议迁移到 utils/serialization) ----
    # TODO: 迁移和实现标准的32字节序列化和反序列化
    def serialize_g1(self, P: G1Point) -> bytes:
        x, y = P
        return x.to_bytes(FIELD_BYTES, 'big') + y.to_bytes(FIELD_BYTES, 'big')

    def deserialize_g1(self, blob: bytes) -> G1Point:
        assert len(blob) == 2 * FIELD_BYTES
        x = int.from_bytes(blob[:FIELD_BYTES], 'big')
        y = int.from_bytes(blob[FIELD_BYTES:], 'big')
        return (x, y)

    # G2/GT 的安全压缩序列化较复杂，这里仅占位，后续完善或统一到 utils
    # TODO: 迁移和实现标准的序列化和反序列化
    def serialize_g2(self, Q: G2Point) -> bytes:
        ((x1, x2), (y1, y2)) = Q
        parts = [x1, x2, y1, y2]
        return b"".join(v.to_bytes(FIELD_BYTES, 'big') for v in parts)

    def deserialize_g2(self, blob: bytes) -> G2Point:
        assert len(blob) == 4 * FIELD_BYTES
        xs = [int.from_bytes(blob[i*FIELD_BYTES:(i+1)*FIELD_BYTES], 'big') for i in range(4)]
        return ((xs[0], xs[1]), (xs[2], xs[3]))
    
    def serialize_gt(self, Z: GTElement) -> bytes:
        # 简化：将 12 个系数按大整数展开；仅用于派生 KDF，不用于持久化
        coeffs = []
        for c in Z.coeffs:  # c 为 FQ2 或 FQ，逐层展开
            if hasattr(c, "coeffs"):
                coeffs.extend([int(x.n) for x in c.coeffs])
            else:
                coeffs.append(int(c.n))
        return b"".join(v.to_bytes(FIELD_BYTES, 'big', signed=False) for v in coeffs)