from .scheme import DecProII

__all__ = ["DecProII"]


