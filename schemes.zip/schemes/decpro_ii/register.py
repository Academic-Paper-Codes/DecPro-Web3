from __future__ import annotations

from typing import Mapping, Sequence

from core.ma_abe import MAABEUserSecretKey

from .scheme import DecProII


def register(
    scheme: DecProII,
    attribute_requests: Mapping[str, Sequence[str]],
) -> MAABEUserSecretKey:
    """DecPro-II 的 Register 算法封装。"""
    return scheme.register(attribute_requests)


