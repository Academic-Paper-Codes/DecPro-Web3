from __future__ import annotations

from typing import Sequence, Tuple

from core.abe_types import AttributeRef
from core.access_tree import AccessTreeNode

from schemes.base import DecProBase


class DecProII(DecProBase[AccessTreeNode]):
    """基于访问控制树的 DecPro-II 封装。"""

    def _policy_satisfied(
        self,
        policy: AccessTreeNode,
        attributes: Sequence[AttributeRef],
    ) -> Tuple[bool, Tuple[AttributeRef, ...]]:
        attr_set = set(attributes)
        satisfied, witnesses = self._check_node(policy, attr_set)
        return satisfied, witnesses

    def _check_node(
        self,
        node: AccessTreeNode,
        attr_set: set[AttributeRef],
    ) -> Tuple[bool, Tuple[AttributeRef, ...]]:
        if node.is_leaf():
            attr = node.attr
            if attr is None or attr not in attr_set:
                return False, ()
            return True, (attr,)

        satisfied_children: list[Tuple[AttributeRef, ...]] = []
        for child in node.children:
            child_satisfied, child_witness = self._check_node(child, attr_set)
            if child_satisfied:
                satisfied_children.append(child_witness)
        if len(satisfied_children) < node.threshold:
            return False, ()

        collected: list[AttributeRef] = []
        for child_attrs in satisfied_children[: node.threshold]:
            for attr in child_attrs:
                if attr not in collected:
                    collected.append(attr)
        return True, tuple(collected)


