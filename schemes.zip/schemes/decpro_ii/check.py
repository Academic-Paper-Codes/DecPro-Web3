from __future__ import annotations

from typing import Sequence

from core.abe_types import AttributeRef
from core.access_tree import AccessTreeNode

from schemes.base import AccessDecision, AccessEvaluator

from .scheme import DecProII


def check(
    scheme: DecProII,
    policy: AccessTreeNode,
    attributes: Sequence[AttributeRef],
    evaluator: AccessEvaluator | None = None,
) -> AccessDecision:
    """DecPro-II 的 Check 算法封装。"""
    return scheme.check(policy, attributes, evaluator=evaluator)


