from __future__ import annotations

from core.access_tree import AccessTreeNode

from schemes.base import CiphertextBundle, DatasetInput, DatasetSerializer

from .scheme import DecProII


def upload(
    scheme: DecProII,
    policy: AccessTreeNode,
    dataset: DatasetInput,
    *,
    aad: bytes = b"",
    serializer: DatasetSerializer | None = None,
) -> CiphertextBundle[AccessTreeNode]:
    """DecPro-II 的 Upload 算法封装。"""
    return scheme.upload(policy, dataset, aad=aad, serializer=serializer)


