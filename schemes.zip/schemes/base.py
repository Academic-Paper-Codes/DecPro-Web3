from __future__ import annotations

import abc
from dataclasses import dataclass
from enum import IntEnum
from typing import (
    Any,
    Callable,
    Dict,
    Generic,
    Iterable,
    Mapping,
    Sequence,
    Tuple,
    TypeVar,
    Union,
    overload,
)

from core.abe_types import AttributeRef
from core.ma_abe import (
    AuthorityKeyPair,
    AuthorityPublicKey,
    MAABECiphertext,
    MAABEUserSecretKey,
    MultiAuthorityABE,
)


PolicyT = TypeVar("PolicyT")

DatasetInput = Union[
    bytes,
    bytearray,
    str,
    Sequence[Union[bytes, bytearray, str]],
]
DatasetSerializer = Callable[[DatasetInput], bytes]
DatasetDeserializer = Callable[[bytes], Any]
AccessEvaluator = Callable[[bool, Sequence[AttributeRef]], "AccessLevel"]


class AccessLevel(IntEnum):
    """定义 DecPro 中的五个访问级别。"""

    UNAUTHORIZED = 0
    EQUALITY = 1
    COMPARISON = 2
    COMPUTATION = 3
    PLAINTEXT = 4


@dataclass(frozen=True)
class AccessDecision:
    """封装 Check 算法的决策结果。"""

    level: AccessLevel
    satisfied: bool
    satisfying_attributes: Tuple[AttributeRef, ...] = ()
    explanation: str = ""

    @property
    def operations(self) -> Tuple[bool, bool, bool, bool, bool]:
        """
        返回 R = (R_u, R_e, R_c, R_h, R_a) 的布尔元组表示。
        Downward-compatible：拥有更高权限意味着拥有所有更低权限。
        """
        return (
            self.level >= AccessLevel.UNAUTHORIZED,
            self.level >= AccessLevel.EQUALITY,
            self.level >= AccessLevel.COMPARISON,
            self.level >= AccessLevel.COMPUTATION,
            self.level >= AccessLevel.PLAINTEXT,
        )


@dataclass(frozen=True)
class CiphertextBundle(Generic[PolicyT]):
    """Upload 算法的输出。"""

    ciphertext: MAABECiphertext
    policy: PolicyT
    aad: bytes
    payload_length: int


@dataclass(frozen=True)
class ProcessResult:
    """Process 算法的输出。"""

    plaintext: bytes
    parsed: Any
    ciphertext: MAABECiphertext


class DecProBase(Generic[PolicyT], abc.ABC):
    """
    DecPro-I 与 DecPro-II 的公共封装逻辑。

    子类只需要实现 `_policy_satisfied`，其余 Setup/Register/Upload/Check/Process
    均可复用。
    """

    def __init__(
        self,
        abe: MultiAuthorityABE | None = None,
        serializer: DatasetSerializer | None = None,
        deserializer: DatasetDeserializer | None = None,
        access_evaluator: AccessEvaluator | None = None,
    ) -> None:
        self.abe = abe or MultiAuthorityABE()
        self._serializer = serializer or self._default_serializer
        self._deserializer = deserializer or self._default_deserializer
        self._access_evaluator = access_evaluator or self._default_access_evaluator
        self._authorities: Dict[str, AuthorityKeyPair] = {}
        self._public_keys: Dict[str, AuthorityPublicKey] = {}

    @staticmethod
    def _default_serializer(data: DatasetInput) -> bytes:
        if isinstance(data, (bytes, bytearray)):
            return bytes(data)
        if isinstance(data, str):
            return data.encode("utf-8")
        if not isinstance(data, Sequence):
            raise TypeError(
                "Dataset input 必须是 bytes/str 或它们组成的序列。"
            )
        parts: list[bytes] = []
        for item in data:
            if isinstance(item, (bytes, bytearray)):
                parts.append(bytes(item))
            elif isinstance(item, str):
                parts.append(item.encode("utf-8"))
            else:
                raise TypeError(
                    "序列元素必须是 bytes/bytearray/str。"
                )
        return b"\n".join(parts)

    @staticmethod
    def _default_deserializer(blob: bytes) -> bytes:
        return blob

    @staticmethod
    def _default_access_evaluator(
        satisfied: bool, _attrs: Sequence[AttributeRef]
    ) -> AccessLevel:
        return AccessLevel.PLAINTEXT if satisfied else AccessLevel.UNAUTHORIZED

    def setup_authority(
        self, authority_id: str, attributes: Sequence[str]
    ) -> AuthorityKeyPair:
        if not authority_id:
            raise ValueError("authority_id 不能为空。")
        distinct_attrs = self._deduplicate_ordered(attributes)
        if not distinct_attrs:
            raise ValueError("attributes 至少包含一个属性。")
        key_pair = self.abe.setup_authority(authority_id, distinct_attrs)
        self._authorities[authority_id] = key_pair
        self._public_keys[authority_id] = key_pair.public
        return key_pair

    def register(
        self, attribute_requests: Mapping[str, Sequence[str]]
    ) -> MAABEUserSecretKey:
        if not attribute_requests:
            raise ValueError("attribute_requests 不能为空。")
        combined = MAABEUserSecretKey()
        for authority_id, attrs in attribute_requests.items():
            key_pair = self._require_authority(authority_id)
            attr_list = self._deduplicate_ordered(attrs)
            if not attr_list:
                continue
            partial = self.abe.issue_user_keys(key_pair.secret, attr_list)
            combined.merge(partial)
        return combined

    def register_for_authority(
        self, authority_id: str, attributes: Sequence[str]
    ) -> MAABEUserSecretKey:
        return self.register({authority_id: attributes})

    def merge_user_keys(
        self, keys: Iterable[MAABEUserSecretKey]
    ) -> MAABEUserSecretKey:
        merged = MAABEUserSecretKey()
        for key in keys:
            merged.components.update(key.components)
        return merged

    def upload(
        self,
        policy: PolicyT,
        dataset: DatasetInput,
        *,
        aad: bytes = b"",
        serializer: DatasetSerializer | None = None,
    ) -> CiphertextBundle[PolicyT]:
        if not self._public_keys:
            raise RuntimeError("尚未执行 Setup，缺少公共密钥。")
        encoder = serializer or self._serializer
        payload = encoder(dataset)
        ciphertext = self.abe.encrypt(
            payload,
            policy,
            self._public_keys,
            aad=aad,
        )
        return CiphertextBundle(ciphertext, policy, aad, len(payload))

    def check(
        self,
        policy: PolicyT,
        attributes: Sequence[AttributeRef],
        evaluator: AccessEvaluator | None = None,
        explanation: str = "",
    ) -> AccessDecision:
        unique_attrs = self._deduplicate_attrs(attributes)
        satisfied, witnesses = self._policy_satisfied(policy, unique_attrs)
        level = (evaluator or self._access_evaluator)(satisfied, witnesses)
        return AccessDecision(level, satisfied, witnesses, explanation)

    @overload
    def process(
        self,
        ciphertext: MAABECiphertext,
        user_keys: MAABEUserSecretKey,
        *,
        deserializer: DatasetDeserializer | None = None,
    ) -> ProcessResult:
        ...

    @overload
    def process(
        self,
        ciphertext: MAABECiphertext,
        user_keys: Sequence[MAABEUserSecretKey],
        *,
        deserializer: DatasetDeserializer | None = None,
    ) -> ProcessResult:
        ...

    def process(
        self,
        ciphertext: MAABECiphertext,
        user_keys: Union[MAABEUserSecretKey, Sequence[MAABEUserSecretKey]],
        *,
        deserializer: DatasetDeserializer | None = None,
    ) -> ProcessResult:
        if isinstance(user_keys, MAABEUserSecretKey):
            merged = MAABEUserSecretKey()
            merged.components.update(user_keys.components)
        else:
            merged = self.merge_user_keys(user_keys)
        plaintext = self.abe.decrypt(ciphertext, merged)
        decoder = deserializer or self._deserializer
        parsed = decoder(plaintext)
        return ProcessResult(plaintext, parsed, ciphertext)

    @property
    def public_keys(self) -> Mapping[str, AuthorityPublicKey]:
        return dict(self._public_keys)

    def _require_authority(self, authority_id: str) -> AuthorityKeyPair:
        try:
            return self._authorities[authority_id]
        except KeyError as exc:
            raise RuntimeError(f"未找到机构 '{authority_id}'，请先执行 Setup。") from exc

    @staticmethod
    def _deduplicate_ordered(values: Sequence[str]) -> list[str]:
        seen: set[str] = set()
        ordered: list[str] = []
        for value in values:
            if value not in seen:
                seen.add(value)
                ordered.append(value)
        return ordered

    @staticmethod
    def _deduplicate_attrs(
        attributes: Sequence[AttributeRef],
    ) -> Tuple[AttributeRef, ...]:
        seen: set[AttributeRef] = set()
        ordered: list[AttributeRef] = []
        for attr in attributes:
            if attr not in seen:
                seen.add(attr)
                ordered.append(attr)
        return tuple(ordered)

    @abc.abstractmethod
    def _policy_satisfied(
        self,
        policy: PolicyT,
        attributes: Sequence[AttributeRef],
    ) -> Tuple[bool, Tuple[AttributeRef, ...]]:
        """判断属性集合是否满足访问策略，并返回满足条件的属性集合。"""


