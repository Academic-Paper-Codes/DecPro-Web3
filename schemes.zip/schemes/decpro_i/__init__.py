from .scheme import DecProI

__all__ = ["DecProI"]


