from __future__ import annotations

from core.access_matrix import LSSSMatrix

from schemes.base import CiphertextBundle, DatasetInput, DatasetSerializer

from .scheme import DecProI


def upload(
    scheme: DecProI,
    policy: LSSSMatrix,
    dataset: DatasetInput,
    *,
    aad: bytes = b"",
    serializer: DatasetSerializer | None = None,
) -> CiphertextBundle[LSSSMatrix]:
    """DecPro-I 的 Upload 算法封装。"""
    return scheme.upload(policy, dataset, aad=aad, serializer=serializer)


