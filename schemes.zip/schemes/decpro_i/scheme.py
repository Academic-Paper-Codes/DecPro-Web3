from __future__ import annotations

from typing import Sequence, Tuple

from core.abe_types import AttributeRef
from core.access_matrix import LSSSMatrix

from schemes.base import DecProBase


class DecProI(DecProBase[LSSSMatrix]):
    """基于访问控制矩阵 (LSSS) 的 DecPro-I 封装。"""

    def _policy_satisfied(
        self,
        policy: LSSSMatrix,
        attributes: Sequence[AttributeRef],
    ) -> Tuple[bool, Tuple[AttributeRef, ...]]:
        try:
            coeffs = policy.satisfy(attributes, self.abe.group.p)
        except ValueError:
            return False, ()
        witnesses = tuple(attr for attr, _ in coeffs)
        return True, witnesses


