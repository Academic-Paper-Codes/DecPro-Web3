from __future__ import annotations

from typing import Sequence

from core.abe_types import AttributeRef
from core.access_matrix import LSSSMatrix

from schemes.base import AccessDecision, AccessEvaluator

from .scheme import DecProI


def check(
    scheme: DecProI,
    policy: LSSSMatrix,
    attributes: Sequence[AttributeRef],
    evaluator: AccessEvaluator | None = None,
) -> AccessDecision:
    """DecPro-I 的 Check 算法封装。"""
    return scheme.check(policy, attributes, evaluator=evaluator)


