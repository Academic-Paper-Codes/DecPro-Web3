from __future__ import annotations

from typing import Sequence

from core.ma_abe import MAABECiphertext, MAABEUserSecretKey

from schemes.base import DatasetDeserializer, ProcessResult

from .scheme import DecProI


def process(
    scheme: DecProI,
    ciphertext: MAABECiphertext,
    user_keys: MAABEUserSecretKey | Sequence[MAABEUserSecretKey],
    *,
    deserializer: DatasetDeserializer | None = None,
) -> ProcessResult:
    """DecPro-I 的 Process 算法封装。"""
    return scheme.process(ciphertext, user_keys, deserializer=deserializer)


