from __future__ import annotations

from typing import Sequence

from core.ma_abe import AuthorityKeyPair

from .scheme import DecProI


def setup(scheme: DecProI, authority_id: str, attributes: Sequence[str]) -> AuthorityKeyPair:
    """DecPro-I 的 Setup 算法封装。"""
    return scheme.setup_authority(authority_id, attributes)


