from __future__ import annotations

import pathlib
import sys

_SRC_ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(_SRC_ROOT) not in sys.path:  # pragma: no cover - 测试环境依赖路径
    sys.path.insert(0, str(_SRC_ROOT))

from core.abe_types import AttributeRef
from core.access_matrix import LSSSMatrix
from core.access_tree import AccessTreeNode
from schemes import AccessLevel, DecProI, DecProII


def _matrix_policy(authority_id: str, attribute: str) -> LSSSMatrix:
    attr_ref = AttributeRef(authority_id, attribute)
    return LSSSMatrix([([1], attr_ref)])


def _tree_policy(authority_id: str, attribute: str) -> AccessTreeNode:
    attr_ref = AttributeRef(authority_id, attribute)
    leaf = AccessTreeNode(1, attr=attr_ref)
    return AccessTreeNode(1, [leaf])


def test_decpro_i_full_flow() -> None:
    scheme = DecProI()
    authority_id = "AUTH"
    attribute = "role_admin"

    scheme.setup_authority(authority_id, [attribute])
    policy = _matrix_policy(authority_id, attribute)
    dataset = ["record-1", "record-2"]

    bundle = scheme.upload(policy, dataset)
    assert bundle.payload_length > 0

    request_attrs = [AttributeRef(authority_id, attribute)]

    decision = scheme.check(policy, request_attrs)
    assert decision.satisfied
    assert decision.level == AccessLevel.PLAINTEXT
    assert decision.operations == (True, True, True, True, True)

    user_key = scheme.register({authority_id: [attribute]})
    result = scheme.process(bundle.ciphertext, user_key)
    assert result.plaintext == result.parsed
    assert b"record-1" in result.plaintext

    unauthorized = scheme.check(policy, [])
    assert not unauthorized.satisfied
    assert unauthorized.level == AccessLevel.UNAUTHORIZED
    assert unauthorized.operations == (True, False, False, False, False)


def test_decpro_ii_full_flow() -> None:
    scheme = DecProII()
    authority_id = "AUTH"
    attribute = "role_data"

    scheme.setup_authority(authority_id, [attribute])
    policy = _tree_policy(authority_id, attribute)

    bundle = scheme.upload(policy, b"payload")
    user_attrs = [AttributeRef(authority_id, attribute)]
    decision = scheme.check(policy, user_attrs)
    assert decision.satisfied

    user_key_single = scheme.register_for_authority(authority_id, [attribute])
    result_single = scheme.process(bundle.ciphertext, user_key_single)
    assert result_single.plaintext == b"payload"

    # 验证 process 支持用户密钥序列输入（协同解密场景）
    key_sequence = [user_key_single]
    result_sequence = scheme.process(bundle.ciphertext, key_sequence)
    assert result_sequence.parsed == b"payload"

    unauthorized = scheme.check(policy, [])
    assert not unauthorized.satisfied
    assert unauthorized.level == AccessLevel.UNAUTHORIZED


