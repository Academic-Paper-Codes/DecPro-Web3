from __future__ import annotations

import pathlib
import sys
from typing import List

import pytest

_SRC_ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(_SRC_ROOT) not in sys.path:  # pragma: no cover - 测试运行环境依赖
    sys.path.insert(0, str(_SRC_ROOT))

from core.abe_types import AttributeRef, MAABEError
from core.access_matrix import LSSSMatrix
from core.access_tree import AccessTreeNode
from core.ma_abe import MultiAuthorityABE


@pytest.fixture()
def maabe() -> MultiAuthorityABE:
    return MultiAuthorityABE()


@pytest.fixture()
def authority_keys(maabe: MultiAuthorityABE):
    return maabe.setup_authority("auth1", ["alpha", "beta", "gamma"])


@pytest.fixture()
def public_keys(authority_keys):
    return {"auth1": authority_keys.public}


def issue_user_key(maabe: MultiAuthorityABE, secret_key, attrs: List[str]):
    return maabe.issue_user_keys(secret_key, attrs)


def test_maabe_sequence_policy_roundtrip(maabe, authority_keys, public_keys):
    policy = [
        AttributeRef("auth1", "alpha"),
        AttributeRef("auth1", "beta"),
    ]
    user_key = issue_user_key(maabe, authority_keys.secret, ["alpha", "beta"])

    plaintext = b"decpro-basic-policy"
    ciphertext = maabe.encrypt(plaintext, policy, public_keys)
    recovered = maabe.decrypt(ciphertext, user_key)

    assert recovered == plaintext
    # 缺少属性时应解密失败
    user_missing = issue_user_key(maabe, authority_keys.secret, ["alpha"])
    with pytest.raises(MAABEError):
        maabe.decrypt(ciphertext, user_missing)


def test_maabe_lsss_policy_roundtrip(maabe, authority_keys, public_keys):
    rows = [
        ([1, 1], AttributeRef("auth1", "alpha")),
        ([1, 0], AttributeRef("auth1", "beta")),
    ]
    policy = LSSSMatrix(rows)
    plaintext = b"decpro-lsss-policy"

    user_key = issue_user_key(maabe, authority_keys.secret, ["alpha", "beta"])
    ciphertext = maabe.encrypt(plaintext, policy, public_keys)
    recovered = maabe.decrypt(ciphertext, user_key)

    assert recovered == plaintext

    user_missing = issue_user_key(maabe, authority_keys.secret, ["alpha"])
    with pytest.raises(MAABEError):
        maabe.decrypt(ciphertext, user_missing)


def test_maabe_access_tree_policy_roundtrip(maabe, authority_keys, public_keys):
    leaf_alpha = AccessTreeNode(1, attr=AttributeRef("auth1", "alpha"))
    leaf_beta = AccessTreeNode(1, attr=AttributeRef("auth1", "beta"))
    root = AccessTreeNode(2, [leaf_alpha, leaf_beta])

    plaintext = b"decpro-tree-policy"
    user_key = issue_user_key(maabe, authority_keys.secret, ["alpha", "beta"])

    ciphertext = maabe.encrypt(plaintext, root, public_keys)
    recovered = maabe.decrypt(ciphertext, user_key)
    assert recovered == plaintext

    user_missing = issue_user_key(maabe, authority_keys.secret, ["alpha"])
    with pytest.raises(MAABEError):
        maabe.decrypt(ciphertext, user_missing)


def test_maabe_tree_policy_supports_aux_attributes(maabe, authority_keys, public_keys):
    # 构造 (alpha AND beta) OR gamma 的访问树
    leaf_alpha = AccessTreeNode(1, attr=AttributeRef("auth1", "alpha"))
    leaf_beta = AccessTreeNode(1, attr=AttributeRef("auth1", "beta"))
    alpha_and_beta = AccessTreeNode(2, [leaf_alpha, leaf_beta])
    leaf_gamma = AccessTreeNode(1, attr=AttributeRef("auth1", "gamma"))
    root = AccessTreeNode(1, [alpha_and_beta, leaf_gamma])  # 阈值 1 表示 OR

    plaintext = b"decpro-star-policy"
    ct = maabe.encrypt(plaintext, root, public_keys)

    # gamma 单独满足策略
    gamma_key = issue_user_key(maabe, authority_keys.secret, ["gamma"])
    assert maabe.decrypt(ct, gamma_key) == plaintext

    # alpha + beta 组合满足策略
    alpha_beta_key = issue_user_key(maabe, authority_keys.secret, ["alpha", "beta"])
    assert maabe.decrypt(ct, alpha_beta_key) == plaintext

    # 单独 alpha 不满足
    alpha_key = issue_user_key(maabe, authority_keys.secret, ["alpha"])
    with pytest.raises(MAABEError):
        maabe.decrypt(ct, alpha_key)