from __future__ import annotations

from typing import Iterable, Any

from core.bilinear_group import FIELD_BYTES, G1Point, G2Point, GTElement


def _coerce_int(value: Any) -> int:
    """
    将 py_ecc 的 FQ/FQ2 子元素或普通整数统一转换为大整数。
    """
    if hasattr(value, "n"):
        return int(value.n)
    try:
        return int(value)
    except (TypeError, ValueError) as exc:
        raise TypeError("无法将给定值转换为整数进行序列化。") from exc


def serialize_scalar(value: Any, length: int = FIELD_BYTES) -> bytes:
    normalized = _coerce_int(value)
    if normalized < 0:
        raise ValueError("不支持将负数序列化为无符号大整数。")
    return normalized.to_bytes(length, "big", signed=False)


def serialize_g1(point: G1Point) -> bytes:
    x, y = point
    return serialize_scalar(x) + serialize_scalar(y)


def deserialize_g1(blob: bytes) -> G1Point:
    if len(blob) != 2 * FIELD_BYTES:
        raise ValueError("Invalid blob length for G1 point")
    x = int.from_bytes(blob[:FIELD_BYTES], "big")
    y = int.from_bytes(blob[FIELD_BYTES:], "big")
    return (x, y)


def serialize_g2(point: G2Point) -> bytes:
    def _serialize_component(component: Any) -> bytes:
        if hasattr(component, "coeffs"):
            return b"".join(serialize_scalar(c) for c in component.coeffs)
        return serialize_scalar(component)

    x, y = point
    return _serialize_component(x) + _serialize_component(y)


def deserialize_g2(blob: bytes) -> G2Point:
    if len(blob) != 4 * FIELD_BYTES:
        raise ValueError("Invalid blob length for G2 point")
    parts = [
        int.from_bytes(blob[i * FIELD_BYTES : (i + 1) * FIELD_BYTES], "big") for i in range(4)
    ]
    return ((parts[0], parts[1]), (parts[2], parts[3]))


def serialize_gt(element: GTElement) -> bytes:
    """
    非压缩序列化：依次展平 GT（FQ12）元素的系数。
    仅用于 KDF/派生，不建议用于持久化。
    """
    coeffs: Iterable[int] = []
    flat: list[int] = []
    for c in element.coeffs:
        if hasattr(c, "coeffs"):
            flat.extend(int(sub.n) for sub in c.coeffs)
        else:
            flat.append(int(c.n))
    return b"".join(serialize_scalar(v) for v in flat)

