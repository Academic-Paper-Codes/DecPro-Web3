# -*- coding: utf-8 -*-

"""
Utility package for DecPro project.
Expose commonly used helpers to simplify imports.
"""

from .lagrange import (
    lagrange_coefficients,
    lagrange_interpolate_at_zero,
    is_span_full_rank,
)
from .serialization import (
    serialize_scalar,
    serialize_g1,
    deserialize_g1,
    serialize_g2,
    deserialize_g2,
    serialize_gt,
)
from .config import DecProConfig, DEFAULT_CONFIG

__all__ = [
    "lagrange_coefficients",
    "lagrange_interpolate_at_zero",
    "is_span_full_rank",
    "serialize_scalar",
    "serialize_g1",
    "deserialize_g1",
    "serialize_g2",
    "deserialize_g2",
    "serialize_gt",
    "DecProConfig",
    "DEFAULT_CONFIG",
]

