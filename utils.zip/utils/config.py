from __future__ import annotations

from dataclasses import dataclass

from core.bilinear_group import BilinearGroup
from core.symmetric_enc import KEY_SIZE, NONCE_SIZE


@dataclass(frozen=True)
class DecProConfig:
    group: BilinearGroup
    symmetric_key_size: int = KEY_SIZE
    nonce_size: int = NONCE_SIZE
    security_level: int = 128  # bits


DEFAULT_CONFIG = DecProConfig(group=BilinearGroup())

