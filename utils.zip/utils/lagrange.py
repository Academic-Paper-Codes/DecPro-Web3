from __future__ import annotations

from functools import lru_cache
from typing import Iterable, Sequence, Tuple


def _validate_points(points: Sequence[Tuple[int, int]]) -> None:
    seen = set()
    for x, _ in points:
        if x in seen:
            raise ValueError(f"Duplicate x-value detected in points: {x}")
        seen.add(x)


@lru_cache(maxsize=512)
def _lagrange_coefficients_cached(xs: Tuple[int, ...], p: int) -> Tuple[int, ...]:
    coeffs = []
    for j, x_j in enumerate(xs):
        numerator = 1
        denominator = 1
        for m, x_m in enumerate(xs):
            if m == j:
                continue
            numerator = (numerator * (-x_m % p)) % p
            denominator = (denominator * ((x_j - x_m) % p)) % p
        coeffs.append((numerator * pow(denominator, -1, p)) % p)
    return tuple(coeffs)


def lagrange_coefficients(x_values: Sequence[int], p: int) -> Sequence[int]:
    """
    Compute λ_j = ∏_{m≠j} (-x_m) / (x_j - x_m) mod p.
    Returns coefficients in the same order as provided x_values.
    """
    xs = tuple(int(x) % p for x in x_values)
    return list(_lagrange_coefficients_cached(xs, p))


def lagrange_interpolate_at_zero(points: Sequence[Tuple[int, int]], p: int) -> int:
    """
    Given [(x_i, y_i)], interpolate the polynomial of degree len(points) - 1
    and evaluate it at 0 (i.e., recover the secret for Shamir shares).
    """
    if not points:
        raise ValueError("No points provided for interpolation")
    _validate_points(points)
    xs = [x for x, _ in points]
    coeffs = lagrange_coefficients(xs, p)
    acc = 0
    for (_, y), coef in zip(points, coeffs):
        acc = (acc + (y % p) * coef) % p
    return acc


def matrix_rank_mod(rows: Iterable[Sequence[int]], p: int) -> int:
    matrix = [list(row) for row in rows]
    if not matrix:
        return 0
    mat = [row[:] for row in matrix]
    rank = 0
    columns = len(mat[0])
    for col in range(columns):
        pivot_row = None
        for r in range(rank, len(mat)):
            if mat[r][col] % p != 0:
                pivot_row = r
                break
        if pivot_row is None:
            continue
        mat[rank], mat[pivot_row] = mat[pivot_row], mat[rank]
        inv = pow(mat[rank][col], -1, p)
        mat[rank] = [(val * inv) % p for val in mat[rank]]
        for r in range(len(mat)):
            if r == rank:
                continue
            factor = mat[r][col] % p
            if factor == 0:
                continue
            mat[r] = [(mat[r][c] - factor * mat[rank][c]) % p for c in range(len(mat[r]))]
        rank += 1
        if rank == columns:
            break
    return rank


def is_span_full_rank(rows: Iterable[Sequence[int]], columns: int, p: int) -> bool:
    return matrix_rank_mod(rows, p) == columns

